<?php

if(!defined("IN_MYBB"))
{
    die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
}

$plugins->add_hook("showthread_start", "info_author_thread");
$plugins->add_hook("forumdisplay_thread", "forumdisplay_created_thread");


function addtemplatefunction_info() 
{
    return array(
        'name'            => 'Dodatki do szablonu',
        'description'    => '',
        'website'        => '',
        'author'        => 'Mateusz "Snake_" Ciećka',
        'authorsite'    => '',
        'version'        => '1.0.0',
        'guid'            => '',
        'compatibility' => '18*'
    );
}

function addtemplatefunction_activate()
 {
	
}

function addtemplatefunction_deactivate()
{
	
}


function info_author_thread()
{
    global $db, $mybb, $thread, $avatar;
	
    $user = get_user($thread['uid']);
	
	$user['username'] = format_name($user['username'], $user['usergroup'], $user['displaygroup']);
	$thread['username_started'] = build_profile_link($user['username'], $user['uid']);

    $avatar = format_avatar($user['avatar']);
    $thread['avatar_started'] = '<a href="member.php?action=profile&uid='.$user['uid'].'"><img src="'.$avatar['image'].'" alt="" /></a>';
	$thread['datethread'] = my_date('relative', $thread['dateline']);
}

function forumdisplay_created_thread() 
{
    global $mybb, $thread;
    
    $thread['datethreadf'] = my_date('relative', $thread['dateline']);

}
